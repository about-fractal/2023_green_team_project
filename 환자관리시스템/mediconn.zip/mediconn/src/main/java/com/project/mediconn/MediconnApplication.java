package com.project.mediconn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MediconnApplication {

	public static void main(String[] args) {
		SpringApplication.run(MediconnApplication.class, args);
	}

}
