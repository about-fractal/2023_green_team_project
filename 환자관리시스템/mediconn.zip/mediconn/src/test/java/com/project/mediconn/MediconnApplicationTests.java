package com.project.mediconn;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MediconnApplicationTests {

	@Test
	void contextLoads() {
	}

}
